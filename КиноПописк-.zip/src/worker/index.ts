import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { z } from "zod";
import { setCookie, getCookie } from "hono/cookie";

const app = new Hono<{ Bindings: Env }>();

// Admin login schema
const AdminLoginSchema = z.object({
  username: z.string(),
  password: z.string(),
});

// Movie schema
const MovieSchema = z.object({
  name: z.string().min(1),
  url: z.string().url(),
});

const MovieUpdateSchema = z.object({
  id: z.number(),
  name: z.string().min(1),
  url: z.string().url(),
});

// Simple admin auth middleware
const adminAuth = async (c: any, next: any) => {
  const sessionToken = getCookie(c, 'admin_session');
  if (sessionToken !== 'admin_authenticated') {
    return c.json({ error: 'Unauthorized' }, 401);
  }
  await next();
};

// Admin login
app.post('/api/admin/login', zValidator('json', AdminLoginSchema), async (c) => {
  const { username, password } = c.req.valid('json');
  
  if (username === 'admin' && password === 'admin2') {
    setCookie(c, 'admin_session', 'admin_authenticated', {
      httpOnly: true,
      path: '/',
      maxAge: 60 * 60 * 24, // 24 hours
    });
    return c.json({ success: true });
  }
  
  return c.json({ error: 'Invalid credentials' }, 401);
});

// Admin logout
app.post('/api/admin/logout', async (c) => {
  setCookie(c, 'admin_session', '', {
    httpOnly: true,
    path: '/',
    maxAge: 0,
  });
  return c.json({ success: true });
});

// Check admin auth status
app.get('/api/admin/status', async (c) => {
  const sessionToken = getCookie(c, 'admin_session');
  return c.json({ authenticated: sessionToken === 'admin_authenticated' });
});

// Search movies
app.get('/api/movies/search', async (c) => {
  const query = c.req.query('q');
  if (!query) {
    return c.json({ error: 'Query parameter required' }, 400);
  }
  
  const { results } = await c.env.DB.prepare(
    'SELECT * FROM movies WHERE LOWER(name) LIKE LOWER(?) LIMIT 1'
  ).bind(`%${query}%`).all();
  
  if (results.length === 0) {
    return c.json({ found: false, message: 'ФИЛЬМА ПОКА НЕТ (((' });
  }
  
  return c.json({ found: true, movie: results[0] });
});

// Get all movies (admin only)
app.get('/api/admin/movies', adminAuth, async (c) => {
  const { results } = await c.env.DB.prepare(
    'SELECT * FROM movies ORDER BY name'
  ).all();
  
  return c.json(results);
});

// Add movie (admin only)
app.post('/api/admin/movies', adminAuth, zValidator('json', MovieSchema), async (c) => {
  const { name, url } = c.req.valid('json');
  
  const result = await c.env.DB.prepare(
    'INSERT INTO movies (name, url, created_at, updated_at) VALUES (?, ?, datetime("now"), datetime("now"))'
  ).bind(name, url).run();
  
  return c.json({ id: result.meta.last_row_id, name, url });
});

// Update movie (admin only)
app.put('/api/admin/movies/:id', adminAuth, zValidator('json', MovieUpdateSchema), async (c) => {
  const { id, name, url } = c.req.valid('json');
  
  await c.env.DB.prepare(
    'UPDATE movies SET name = ?, url = ?, updated_at = datetime("now") WHERE id = ?'
  ).bind(name, url, id).run();
  
  return c.json({ id, name, url });
});

// Delete movie (admin only)
app.delete('/api/admin/movies/:id', adminAuth, async (c) => {
  const id = parseInt(c.req.param('id'));
  
  await c.env.DB.prepare('DELETE FROM movies WHERE id = ?').bind(id).run();
  
  return c.json({ success: true });
});

export default app;
