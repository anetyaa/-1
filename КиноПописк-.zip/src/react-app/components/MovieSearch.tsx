import { useState } from 'react';
import { Search, ExternalLink } from 'lucide-react';

interface Movie {
  id: number;
  name: string;
  url: string;
}

export default function MovieSearch() {
  const [query, setQuery] = useState('');
  const [result, setResult] = useState<{ found: boolean; movie?: Movie; message?: string } | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    try {
      const response = await fetch(`/api/movies/search?q=${encodeURIComponent(query)}`);
      const data = await response.json();
      setResult(data);
    } catch (error) {
      console.error('Search error:', error);
      setResult({ found: false, message: 'ОШИБКА ПОИСКА' });
    } finally {
      setLoading(false);
    }
  };

  const openMovie = (url: string) => {
    window.open(url, '_blank');
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-6">
      <form onSubmit={handleSearch} className="mb-8">
        <div className="relative">
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Введите название фильма..."
            className="w-full px-4 py-4 pr-12 text-lg border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none transition-colors bg-white/80 backdrop-blur-sm"
          />
          <button
            type="submit"
            disabled={loading}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-500 hover:text-blue-500 transition-colors"
          >
            <Search className={`w-6 h-6 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </form>

      {result && (
        <div className="text-center">
          {result.found && result.movie ? (
            <div className="bg-green-50 border border-green-200 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-green-800 mb-4">
                Фильм найден!
              </h3>
              <p className="text-green-700 mb-4 capitalize">
                {result.movie.name}
              </p>
              <button
                onClick={() => openMovie(result.movie!.url)}
                className="inline-flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <ExternalLink className="w-4 h-4" />
                Смотреть фильм
              </button>
            </div>
          ) : (
            <div className="bg-red-50 border border-red-200 rounded-xl p-6">
              <p className="text-xl font-semibold text-red-800">
                {result.message || 'ФИЛЬМА ПОКА НЕТ ((('}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
