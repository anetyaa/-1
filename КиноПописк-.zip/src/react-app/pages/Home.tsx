import { useState, useEffect } from 'react';
import { Film, Settings } from 'lucide-react';
import MovieSearch from '@/react-app/components/MovieSearch';
import AdminLogin from '@/react-app/components/AdminLogin';
import AdminPanel from '@/react-app/components/AdminPanel';

export default function Home() {
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    checkAdminAuth();
  }, []);

  const checkAdminAuth = async () => {
    try {
      const response = await fetch('/api/admin/status');
      const data = await response.json();
      setIsAdminAuthenticated(data.authenticated);
    } catch (error) {
      console.error('Error checking auth:', error);
    } finally {
      setCheckingAuth(false);
    }
  };

  const handleAdminLogin = () => {
    setShowAdminLogin(false);
    setIsAdminAuthenticated(true);
  };

  const handleAdminLogout = async () => {
    try {
      await fetch('/api/admin/logout', { method: 'POST' });
      setIsAdminAuthenticated(false);
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  if (checkingAuth) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (isAdminAuthenticated) {
    return <AdminPanel onLogout={handleAdminLogout} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Background decorative elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-1/2 -right-1/2 w-full h-full bg-gradient-to-l from-blue-200/20 to-transparent rounded-full blur-3xl"></div>
        <div className="absolute -bottom-1/2 -left-1/2 w-full h-full bg-gradient-to-r from-purple-200/20 to-transparent rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10">
        {/* Header */}
        <header className="flex justify-between items-center p-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Film className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              КиноПописк-
            </h1>
          </div>
          
          <button
            onClick={() => setShowAdminLogin(true)}
            className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-white/50 rounded-lg transition-all duration-200"
          >
            <Settings className="w-4 h-4" />
            Админ
          </button>
        </header>

        {/* Main Content */}
        <main className="flex flex-col items-center justify-center px-6 pt-16 pb-32">
          <div className="text-center mb-12">
            <h2 className="text-5xl font-bold text-gray-900 mb-4">
              Найди свой{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                фильм
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Поиск и просмотр фильмов онлайн. Просто введите название и начинайте смотреть!
            </p>
          </div>

          <MovieSearch />

          {/* Features */}
          <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center p-6 bg-white/40 backdrop-blur-sm rounded-2xl border border-white/20">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Film className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Быстрый поиск
              </h3>
              <p className="text-gray-600">
                Мгновенный поиск фильмов по названию
              </p>
            </div>
            
            <div className="text-center p-6 bg-white/40 backdrop-blur-sm rounded-2xl border border-white/20">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Settings className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Простота
              </h3>
              <p className="text-gray-600">
                Интуитивно понятный интерфейс
              </p>
            </div>
            
            <div className="text-center p-6 bg-white/40 backdrop-blur-sm rounded-2xl border border-white/20">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Film className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Прямые ссылки
              </h3>
              <p className="text-gray-600">
                Быстрый переход к просмотру
              </p>
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="text-center py-8 text-gray-500">
          <p>&copy; 2024 КиноПописк-. Все права защищены.</p>
        </footer>
      </div>

      {/* Admin Login Modal */}
      {showAdminLogin && (
        <AdminLogin onLogin={handleAdminLogin} />
      )}
    </div>
  );
}
