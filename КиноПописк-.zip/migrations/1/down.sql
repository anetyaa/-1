
DROP TABLE movies;
