
CREATE TABLE movies (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  url TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert some sample data
INSERT INTO movies (name, url) VALUES ('супермен', 'https://www.sspoisk.ru/film/997647/?utm_referrer=yandex.ru');
INSERT INTO movies (name, url) VALUES ('человек-паук', 'https://www.example.com/spiderman');
INSERT INTO movies (name, url) VALUES ('бэтмен', 'https://www.example.com/batman');
